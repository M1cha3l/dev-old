<html>
<head>
<title>
get-table.php
</title>
</head>
<body>

<form action="print-table.php" method="POST">
<b>Enter the name of the table you want to post:</b>
<input type="text" name="table">
<p>
<input type="submit" value="submit">
</form>

<a href="main1.php"> back to menu </a>

</body>
</html>