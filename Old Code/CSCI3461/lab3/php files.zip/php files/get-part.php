<html>
<head>
<title>
get-part.php
</title>
</head>

<body>
<b><font size = "5">Add New Part</font></b>
<p>
<form action="insert-part.php" method="POST">
<b>Enter the part number:</b>
<input type="text" name="idNo">
<p>
<b>Enter the part price:</b>
<input type="text" name="price">
<p>
<b>Enter the part description:</b>
<input type="text" name="descr">
<p>
<b>Enter the part quantity:</b>
<input type="text" name="stock">
<p>
<input type="submit" value="submit">
</form>
</body>

<a href="main1.php"> back to menu </a>

</html>