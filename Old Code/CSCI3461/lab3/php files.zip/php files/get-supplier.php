<html>
<head>
<title>
get-supplier.php
</title>
</head>

<body>
<b><font size="5">Add New Supplier</font></b>
<p>
<form action="insert-supplier.php" method="POST">
<b>Enter the supplier's name:</b>
<input type="text" name="name">
<p>
<b>Enter the supplier's address:</b>
<input type="text" name="addr">
<p>
<input type="submit" value="submit">
</form>
</body>

<a href="main1.php"> back to menu </a>

</html>