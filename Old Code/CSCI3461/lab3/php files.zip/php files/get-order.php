<html>
<head>
<title>
get-order.php
</title>
</head>

<body>
<b><font size="5">Add New Order</font></b>
<p>
<form action="insert-order.php" method="POST">
<b>Enter the order number:</b>
<input type="text" name="idNo">
<p>
<b>Enter the order supplier's name:</b>
<input type="text" name="supName">
<p>
<b>Enter the order part number:</b>
<input type="text" name="pIdNo">
<p>
<b>Enter the order quantity:</b>
<input type="text" name="quantity">
<p>
<b>Enter the order price:</b>
<input type="text" name="cost">
<p>
<input type="submit" value="submit">
</form>
</body>

<a href="main1.php"> back to menu </a>

</html>
