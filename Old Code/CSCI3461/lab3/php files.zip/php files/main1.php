<html>
<head>
<title>
main1.php
</title>
</head>

<body>
<b>MUC Main Menu</b>
<p>
<a href="get-supplier.php"> New Supplier </a> <p>
<a href="get-part.php"> New Part </a> <p>
<a href="get-order.php"> New Order </a> <p>
<a href="cancel-order.php"> Cancel Order </a> <p>
<a href="get-table.php"> Print table </a> <p>
<a href="http://cs.smu.ca/~stavros/courses/current/3461"> back to the
csci3461 page</a>

</body>

</html>